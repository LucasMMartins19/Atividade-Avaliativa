package com.mycompany.atividade;

import java.util.Scanner;

public class Ativ_2 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        int vit = 0;
        char result;

        for (int i = 0; i < 6; i++) {
            System.out.println("Informe o resultado do jogo: (V)-para venceu, (P)-para perdeu");
            result = ler.next().charAt(0);
            if (result == 'V') {
                vit++;
            }
        }

        if (vit >= 5) {
            System.out.println(1);
        } else if (vit >= 3) {
            System.out.println(2);
        } else if (vit >= 1){
            System.out.println(3);
        } else {
            System.out.println(-1);
        }

    }

}
