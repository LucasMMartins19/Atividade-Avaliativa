package com.mycompany.atividade;

import java.util.Arrays;
import java.util.Scanner;

public class Ativ_1 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        int[] idade = new int[3];

        System.out.println("Informe as idades");
        idade[0] = ler.nextInt();
        idade[1] = ler.nextInt();
        idade[2] = ler.nextInt();

        Arrays.sort(idade);

        System.out.println("A idade de camila é: " + idade[1]);

    }
}
