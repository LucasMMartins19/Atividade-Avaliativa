package com.mycompany.atividade;

import java.util.Scanner;

public class Ativ_4 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = scanner.nextInt();

        int totalPecas = ((n + 1) * (n + 2)) / 2;

        System.out.println(totalPecas);

    }
}
