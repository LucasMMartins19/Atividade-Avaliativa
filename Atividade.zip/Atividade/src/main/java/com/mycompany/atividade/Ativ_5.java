package com.mycompany.atividade;

import java.util.Scanner;

public class Ativ_5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n1 = scanner.nextInt();
        double d1 = scanner.nextDouble();
        double v1 = scanner.nextDouble();

        int n2 = scanner.nextInt();
        double d2 = scanner.nextDouble();
        double v2 = scanner.nextDouble();

        double tempo1 = d1 / v1;
        double tempo2 = d2 / v2;

        if (tempo1 < tempo2) {
            System.out.println(n1);
        } else {
            System.out.println(n2);
        }

        scanner.close();
    }
}