package com.mycompany.atividade;

import java.util.Scanner;

public class Ativ_3 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int s = scanner.nextInt();
        int a = scanner.nextInt();
        int b = scanner.nextInt();

        int quantidade = 0;

        for (int i = a; i <= b; i++) {
            int numero = i;
            int somaDigitos = 0;

            while (numero > 0) {
                somaDigitos += numero % 10;
                numero /= 10;
            }

            if (somaDigitos == s) {
                quantidade++;
            }
        }

        System.out.println(quantidade);

    }
}
